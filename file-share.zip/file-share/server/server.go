package server

import (
	"github.com/labstack/echo"
)

func Create() *echo.Echo {
	return echo.New()
}