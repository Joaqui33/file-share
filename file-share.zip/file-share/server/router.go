package server

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"github.com/labstack/echo"
	"html/template"
	"net/http"
	"reflect"
)

const routesPath string = "config/routes.json"

<<<<<<< Updated upstream
type IRoutes interface {
	parseRoutes()
	BuildRoutes()
}

type Route struct {
	Name   		string
	Method 		string
	Path   		string
	Controller	string
}

type Handler struct{}

var routes []Route

func parseRoutes() {

	unparsedJSONRoutes, err := ioutil.ReadFile(routesPath)
	if err != nil {
		log.Fatal(err)
	}

	err = json.Unmarshal(unparsedJSONRoutes, &routes)
	if err != nil {
		log.Fatal(err)
	}

}
=======
	e.Static("/generalStyles", "public/assets")

	e.GET("/", func(c echo.Context) error {
		return home.Home(e, c)
	})
>>>>>>> Stashed changes

func BuildRoutes(e echo.Echo) {

	parseRoutes()

	renderer := &TemplateRenderer{
		Templates: template.Must(template.ParseGlob("public/views/sharefile/*.html")),
	}

	e.Renderer = renderer

	for _, route := range routes {
		switch route.Method {
			case "GET":
				e.GET(route.Path, func(c echo.Context) error {
					return router(c, route.Controller)
				})
		}
	}


}

func router(c echo.Context, controller string) error {

	return reflect.ValueOf().MethodByName(controller)
}




