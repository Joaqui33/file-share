package sharefile

func UploadFile() {

}