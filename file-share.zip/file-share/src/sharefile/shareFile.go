package sharefile

import (
	"github.com/labstack/echo"
	"net/http"
)

func ShareFile(c echo.Context) error {
	return c.String(http.StatusOK, "verga")
}