package main

import (
	"Sonnys/file-share/server"
	"github.com/labstack/echo"
	"net/http"
)

const routesPath string = "config/routes.json"

func main() {
	e := server.Create()

	server.BuildRoutes(*e)

	e.GET("/something", func(c echo.Context) error {
		return c.Render(http.StatusOK, "share-file-form.html", map[string]interface{}{
			"name": "Dolly!",
		})
	}).Name = "foobar"


	e.Logger.Fatal(e.Start(":8080"))

}